//
//  mapViewController.swift
//  mapViewExample
//
//  Created by Tops on 4/13/17.
//  Copyright © 2017 Tops. All rights reserved.
//

import UIKit
import MapKit

class mapViewController: UIViewController, MKMapViewDelegate {

   
    @IBOutlet weak var myMap: MKMapView!
    
    var arr = [Double]()
    var name = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        for i in arr{
        print(i)
        }
        let lat = arr[0]
        let long = arr[1]
        let coordinate = CLLocationCoordinate2DMake(lat, long)
        let around:CLLocationDistance = 5000
        
        let region = MKCoordinateRegionMakeWithDistance(coordinate, around, around)
        
        myMap.setRegion(region, animated: true)
        let pin = MyPinOnMap (title: "\(name)", subtitle: "Hi !", coordinate: coordinate)
        myMap.addAnnotation(pin)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "pin")
        annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "pin")
        annotationView?.canShowCallout = true
        //annotationView?.image = UIImage(named: "custom_pin.png")
        
        annotationView?.image = #imageLiteral(resourceName: "mappin1")
        return annotationView
        
    }

    
}

class MyPinOnMap:NSObject, MKAnnotation{
    var title: String?
    var subtitle: String?
    var coordinate: CLLocationCoordinate2D
    
    init(title:String,subtitle:String,coordinate:CLLocationCoordinate2D) {
        
        self.title = title
        self.subtitle = subtitle
        self.coordinate = coordinate
        
    }
}

