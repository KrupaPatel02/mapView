//
//  ViewController.swift
//  mapViewExample
//
//  Created by Tops on 4/13/17.
//  Copyright © 2017 Tops. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITableViewDataSource, UITableViewDelegate{

    @IBOutlet weak var countrytblView: UITableView!
    
    var CountryList = [[String:Any]]()
    var displayDataList = [[String:Any]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        countrytblView.delegate = self
       
        do{
        let url = URL(string: "https://restcountries.eu/rest/v2/all")
        let data = try Data.init(contentsOf: url!)
        self.CountryList = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves) as! [[String:Any]]
        print(self.CountryList)
        var i = 0
            for row in self.CountryList{
                
                
                var d = [String:Any]()
//                if (row["latlng"] != nil){
//                    let latlngVal:[Double] = row["latlng"] as! [Double]
//                    let strArr = latlngVal.flatMap{String($0)}
//                    let str = strArr.joined(separator: ",")
//                    
//                    for i in strArr{
//                        print(i)
//                    }
//                    d["latlng"] = str
//                    
//                }
//                for (key,value) in d{
//                    if key == "latlng"
//                    {
//                        print(value)
//                    }
//                
//                }
                
                d["name"] = row["name"]
                d["capital"] = row["capital"]
                d["latlng"] = row["latlng"]
                
              i += 1
                self.displayDataList.append(d)
                print(i)

                
            }
            print("***", self.CountryList.count)
            print(self.displayDataList.count)
           
            self.countrytblView.reloadData()
        }
        catch let er as NSError{
            print("Error:" , er)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return self.displayDataList.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "country")
        
        let row = displayDataList[indexPath.section]
        cell?.textLabel?.text = row["name"] as? String
        cell?.detailTextLabel?.text = row["capital"] as? String
        //cell?.detailTextLabel?.text = "\([row["latlng"]!)"
        return cell!

    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let _selectedllocation = displayDataList[indexPath.section]
 
        
        let mapView = self.storyboard?.instantiateViewController(withIdentifier: "mapShow") as! mapViewController
        
        mapView.name = _selectedllocation["name"] as! String
        mapView.arr = _selectedllocation["latlng"] as! [Double]
        
        
        for i in mapView.arr{
        print(i)
        }
        
        self.navigationController?.pushViewController(mapView, animated: true)
        
    }
    
    
}

